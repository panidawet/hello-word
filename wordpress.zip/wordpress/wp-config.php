<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'root');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '=Q$$,m%<R9?{0_PD,}zqdU`-bh!D]26eQas=xXaod 6p0NaJUZ4-Uf7B|0Gr_:02');
define('SECURE_AUTH_KEY',  '+P.:s]KqCT5px{jUW|IEA}{)?p9+ Fc:+}`D$xgVI]zwhjpJ:`:cQBx9ZUPM$7Pr');
define('LOGGED_IN_KEY',    'XO/O9M*Wh`<[S{,.#I+k D&;BgMDh 4,3RHH^X8E]lT:_,Pk;qmPxR>:5kC~QD#{');
define('NONCE_KEY',        'c>bgQ24v!^4QZ-Wg6 gU9&i2 jx*0rFA;F{H*1dI9WT=)<DdP{f3:!WBaL)>u2p-');
define('AUTH_SALT',        ']sHM~O72qZT4/tC+=iby?~][KSx<G?&X:mITl+.lu#9CO3,Ie(CB9AK2m)6BD6OU');
define('SECURE_AUTH_SALT', 'D[XL:bO>+?R06?u1/z/$uY5 Z2U]m+vyZ5Z&0}.w>db{d|kJR8D{k+UP^o-o|i46');
define('LOGGED_IN_SALT',   't=9cYqLf{5mH/c&<9NxBz1rp{+vwAYZKBx%Iswp>L=wz^0f 6M[7UNXdq;@H[|0>');
define('NONCE_SALT',       'SN_,ve9xs/ed 0cPny|K6jZZ&Nwm%eWO:bO_j|H|]o2l:aaYU^=S{-n%uNs1:`00');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
